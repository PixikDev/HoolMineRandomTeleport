package pixik.ru.hoolminerandomteleport;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class HoolMineRandomTeleport extends JavaPlugin {

    private final Map<Player, Long> cooldowns = new HashMap<>();
    private final long COOLDOWN_TIME = 30 * 1000;
    private final int MAX_RADIUS = 3000;
    private final Random random = new Random();

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("rtp")) {
            return false;
        }

        if (!(sender instanceof Player)) {
            sender.sendMessage("Эта команда доступна только игрокам!");
            return true;
        }

        Player player = (Player) sender;

        if (cooldowns.containsKey(player)) {
            long timeLeft = (cooldowns.get(player) + COOLDOWN_TIME) - System.currentTimeMillis();
            if (timeLeft > 0) {
                player.sendMessage(String.format("Подождите ещё %d секунд перед использованием команды!",
                        timeLeft / 1000));
                return true;
            }
        }

        World world = Bukkit.getWorld("world");
        if (world == null) {
            player.sendMessage("Мир 'world' не найден!");
            return true;
        }

        int x = random.nextInt(MAX_RADIUS * 2) - MAX_RADIUS;
        int z = random.nextInt(MAX_RADIUS * 2) - MAX_RADIUS;
        int y = world.getHighestBlockYAt(x, z) + 1;

        Location randomLocation = new Location(world, x + 0.5, y, z + 0.5);

        new BukkitRunnable() {
            @Override
            public void run() {
                player.teleport(randomLocation);
                player.sendMessage("Вы были телепортированы на координаты: " +
                        x + ", " + y + ", " + z + "!");
            }
        }.runTask(this);

        cooldowns.put(player, System.currentTimeMillis());

        return true;
    }
}